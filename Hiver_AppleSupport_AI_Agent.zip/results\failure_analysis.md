# Top 5 Failure Modes

## 1. Intent Classification Failure
- **ID**: 596916
- **Customer Text**: FIX IT @115858
- **Expected Intent**: context_provided
- **Predicted Intent**: other_complaint (Confidence: 0.96)
- **Expected Action**: AUTO_HANDLE
- **Predicted Action**: ESCALATE
- **Generated Reply**: [FALLBACK - Grounded] Here’s what you can do to work around the issue until it’s fixed in a future software update:

### Why it failed:
The TF-IDF classifier matched generic words (e.g. "update", "battery") more strongly than the true underlying issue context.

### Hypothesis:
Simple Bag-of-Words models fail on multi-sentence or slightly nuanced complaints where keywords from multiple intents are present.

### Possible Fix:
Switching to the Dense Embedding Classifier (SentenceTransformers) as the primary classifier, which understands semantic context better than TF-IDF.

---

## 2. Escalation Policy Failure (Pseudo-label Mismatch)
- **ID**: 2002212
- **Customer Text**: @applesupport. hi. word on the street is i can inquire about my phone's battery life here. seems to be dying ...
- **Expected Intent**: battery_issue
- **Predicted Intent**: battery_issue (Confidence: 0.93)
- **Expected Action**: ESCALATE
- **Predicted Action**: AUTO_HANDLE
- **Generated Reply**: [FALLBACK - Grounded] We're happy to help out however we can! What device is this for, and are you noticing an issue with the battery life of the device?

### Why it failed:
The predicted action differs from the expected action, primarily because the expected action in the golden set is currently a heuristic pseudo-label (partially randomized), whereas the system applies a strict threshold.

### Hypothesis:
The 42% escalation accuracy is an artifact of the unreviewed random pseudo-labels in the golden set, not a true reflection of the escalation logic.

### Possible Fix:
Requires manual human review of the golden set (Phase 10) to establish true escalation expectations.

---

## 3. Ambiguous Intent (Low Confidence)
- **ID**: 2239373
- **Customer Text**: Rang @115858 support for help getting my iCloud to fucking work and ended up losing every photo/video I have, fucking good 1 apple, cheers👍🏼
- **Expected Intent**: keyboard_autocorrect_bug
- **Predicted Intent**: other_complaint (Confidence: 0.31)
- **Expected Action**: AUTO_HANDLE
- **Predicted Action**: ESCALATE
- **Generated Reply**: [FALLBACK - Grounded] We're here to help. Let us know what is going on and we can go from there together.

### Why it failed:
The model was very unsure of the intent because the customer message was extremely brief or lacked technical keywords.

### Hypothesis:
The escalation policy correctly caught this by forcing an ESCALATE due to low confidence, preventing a hallucinated bot response.

### Possible Fix:
This is a successful failure mitigation. To fix the underlying low confidence, we need to inject conversational context (previous turns) instead of evaluating single isolated tweets.

---

## 4. Intent Classification Failure (Over-classification)
- **ID**: 1470688
- **Customer Text**: @AppleSupport DO SOMETHING @115858 https://t.co/dIDiJhhclj
- **Expected Intent**: other_complaint
- **Predicted Intent**: context_provided (Confidence: 0.51)
- **Expected Action**: AUTO_HANDLE
- **Predicted Action**: AUTO_HANDLE
- **Generated Reply**: [FALLBACK - Grounded] Let's see how we can help. Is your music pausing when taking any specific actions? Which iOS update is currently installed?

### Why it failed:
The customer was making a generic rant, but used a keyword that triggered a specific technical intent.

### Hypothesis:
The TF-IDF model over-indexes on specific rare words, forcing vague complaints into technical buckets.

### Possible Fix:
Train a robust background "chit-chat/rant" intent using embeddings rather than exact word matches.

---

## 5. Response Generation Failure (DETERMINISTIC_FALLBACK)
- **ID**: 523825
- **Customer Text**: @241073 @AppleSupport I have that problem too. Please help
- **Expected Intent**: keyboard_autocorrect_bug
- **Predicted Intent**: other_complaint (Confidence: 0.52)
- **Expected Action**: AUTO_HANDLE
- **Predicted Action**: ESCALATE
- **Generated Reply**: [FALLBACK - Grounded] We've released an update that includes a fix for autocorrect issues. Be sure to back up your device prior to updating, and let us know if the issue persists afterwards.

### Why it failed:
Ollama was unavailable, so the system relied on the DETERMINISTIC_FALLBACK_JUDGE and template. The template lacks empathy, personalization, and cannot synthesize multiple documents.

### Hypothesis:
Fallback responses are rigid and do not resolve complex issues, serving only as a safety net.

### Possible Fix:
Deploy the pipeline on a machine with Ollama running the Llama-3.1 model to enable true generative responses.

---

